CALENDRIER DE L'AVENT 2026 — CRÉATIONS SUBLIMATION
Prix de vente décidé : 45 $ par client.

PUBLICATION GRATUITE SUR GITHUB PAGES
1. Connectez-vous sur https://github.com et créez un dépôt PUBLIC, par exemple calendrier-avent-2026.
2. Dans le dépôt, cliquez Add file > Upload files, puis déposez index.html (à la racine du dépôt) et validez avec Commit changes.
3. Ouvrez Settings > Pages.
4. Dans Build and deployment, sélectionnez Deploy from a branch, puis main et / (root). Enregistrez.
5. GitHub affiche ensuite l'adresse du site, typiquement https://VOTRE-NOM.github.io/calendrier-avent-2026/.

IMPORTANT — LIMITES
- Un dépôt GitHub Pages PUBLIC ne permet pas de restreindre l'accès aux acheteurs. Toute personne avec le lien peut voir le site, et les offres sont lisibles dans le code source.
- Les dates sont vérifiées dans le navigateur, donc un utilisateur technique peut contourner le verrouillage. Il ne s'agit PAS d'un système sécurisé.
- Aucune carte-cadeau unique n'est émise automatiquement et aucun paiement n'est traité par ce site.
- Gérez les ventes, preuves d'achat et numéros de cartes-cadeaux séparément dans Square ou vos registres.
- Les offres de l'inventaire sont sous réserve de disponibilité. Définissez les articles admissibles à l'offre du 21 décembre avant de lancer.
- Testez le site avant de le partager aux clients.
